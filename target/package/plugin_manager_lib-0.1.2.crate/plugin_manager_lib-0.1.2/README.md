# 本地使用:

```rust
plugin_manager_lib = {path = "/home/banchen/文档/rust_demo/plugin_manager_lib" }
```

# 使用最新:

```rust
plugin_manager_lib = {git = "https://github.com/MC-PMA/plugin_manager_lib" }
```
